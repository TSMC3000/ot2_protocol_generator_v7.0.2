from .protocol import OT2ProcGenerator
# from .protocol_v2 import OT2ProcGenerator as OT2ProcGenerator_v2
from .protocol_v7 import OT2ProcGenerator as OT2ProcGeneratorV7
